<?php
include 'config.php';
error_reporting(0);
$merid = "12345"; //apikey کد نکست پی
$callback_uri = "$web/callback"; //لینک برگشت 
function RandomString() {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrswxyz1234567890';
    $randstring = null;
    for ($i = 0; $i < 9; $i++) {
        $randstring .= $characters[
            rand(0, strlen($characters))
        ];
    }
    return $randstring;
}
$amount = $_GET["amount"];
$id = $_GET["id"];

$arr = array('userid' => $id, 'amount' => $amount);
$data = json_encode($arr);
$oder = RandomString();
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://nextpay.org/nx/gateway/token',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => "api_key=$merid&amount=$amount&custom_json_fields=$data&order_id=$oder&callback_uri=$callback_uri",
));

$response = curl_exec($curl);

curl_close($curl);
$_array = json_decode($response , true);
$trans_id = $_array['trans_id'];
header('location: https://nextpay.org/nx/gateway/payment/'.$trans_id.'')
?>