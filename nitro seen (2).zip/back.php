<?php
/*
@ImDevAbolfazl
*/
ob_start();
error_reporting(0);
include('config.php');
include('lib/jdf.php');
$token = 'توکن';// bot token
$admin = [123456]; // admin id
$time = jdate('H:i:s');
$date = jdate('j F Y');
define('API_KEY',$token);
$setting = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `setting` LIMIT 1"));
$cbvarizi="@SeenOrderPanda";// channel pay
//========================================================
function bot($method, $datas = []){
$url = "https://api.telegram.org/bot".API_KEY."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL, $url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS, $datas);
$res = curl_exec($ch);
if(curl_error($ch)) {
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}
//========================================================
function sendmessage($chat_id,$text){
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => $text,
'parse_mode' => "MarkDown",
]);
}
//========================================================
$MerchantID = "{$setting['MerchantID']}";
$Amount = $_GET['amount'];
$Authority = $_GET['Authority'];
// $coin = $_GET['coin'];
$user = $_GET['id'];
//============================
if($_GET['Status'] == 'OK'){
$client = new SoapClient('https://www.zarinpal.com/pg/services/WebGate/wsdl', ['encoding' => 'UTF-8']);
$result = $client->PaymentVerification(['MerchantID' => $MerchantID,'Authority' => $Authority,'Amount' => $Amount,]);
if($result->Status == 100){
$userdata = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));
$pluscoin = $userdata['coin']+ $Amount;
echo 'خرید شما با موفقیت انجام شد کد پیگیری » '.$result->RefID;
header("location: tg://resolve?domain=$botname");
bot('sendmessage',[
'chat_id'=>$user,
'text'=>"✅ تراکنش شما با موفقیت انجام شد و موجودی حساب شما افزایش یافت.

☑️ مبلغ پرداخت شده : $Amount تومان
💰 موجودی جدید شما : $pluscoin سکه
⏱ زمان پرداخت : $time
📆 تاریخ : $date
💐 با تشکر از خرید شما",
'parse_mode'=>'Markdown',
]);
$connect->query("UPDATE `user` SET `coin` = '$pluscoin' WHERE `id` = '$user' LIMIT 1");
$connect->query("INSERT INTO `buy` (`id` , `amount` , `time`) VALUES ('$user' , '$Amount' , '$time')");
$user222 = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));	
$ippardakhkonnande = $_SERVER['REMOTE_ADDR'];
$coinghadim = $pluscoin - $Amount;
bot('sendmessage',[
'chat_id'=>$setting['channelkharid'],
'text'=>"✅ یک پرداخت با مشخصات زیر هم اکنون صورت گرفت.

☑️ مبلغ پرداخت شده : $Amount تومان
💰 موجودی قدیم کاربر : $coinghadim سکه
💰 موجودی جدید کاربر : $pluscoin سکه
⏱ زمان پرداخت : $time
📆 تاریخ : $date
👤 [جهت مشاهده کاربر کلیک نمایید.](tg://user?id=$user)
📞 شماره فرد = {$user222['phone']}
📍 آیپی فرد پرداخت کننده : $ippardakhkonnande
",
'parse_mode'=>'Markdown',
]);
if($userdata['inviter'] != '0'){
$userinviter = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '{$userdata['inviter']}' LIMIT 1"));
$porsant = ($Amount * $setting['porsant']) / 100 ;
$coinplusinviter = $userinviter["coin"] + $porsant;
bot('sendmessage',[
  'chat_id'=>$userdata['inviter'],
  'text'=>"✅ تبریک ! زیر مجموعه شما از ربات خرید کرد و 10 درصد از موجودی خریداری شده به عنوان هدیه به شما تعلق گرفت
🗣 موجودی حساب شما با موفقیت افزایش  یافت , در صورت وجود هر گونه ایراد کافیست با پشتیبانی در تماس باشید .
  
🛍 موجودی خریداری شده : $Amount تومان
💰 موجودی جدید شما : $coinplusinviter تومان
❄️ موجودی قبلی : {$userinviter["coin"]} تومان
🎁 مقدار هدیه : $porsant تومان
👤 خرید توسط : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
$connect->query("UPDATE user SET coin = '$coinplusinviter' WHERE id = '{$userdata['inviter']}' LIMIT 1");
}
}else{
echo 'پرداخت شما قبلا ثبت شده است » '.$result->RefID;
header("location: tg://resolve?domain=$botname");
}
}else{
echo 'پرداخت انجام نشد » '.$result->RefID;
header("location: tg://resolve?domain=$botname");
bot('sendmessage',[
'chat_id'=>$user,
'text'=>"❌ پرداخت شما انجام نشد.

⚠️ جهت مجدد خرید باید دوباره اقدام نمایید و با لینک جدید وارد درگاه پرداخت شوید.",
'parse_mode'=>'html',
]);
}
/*
@ImDevAbolfazl
*/
?>
