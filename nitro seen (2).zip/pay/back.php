<?php
# -- @DevAbolfazl -- @IRA_Team -- #
include '../botedmatike3iotfaka.php';
include '../config.php';
//==============================================================
$user = $_GET['id'];
$amount = $_GET['amount'];
$id = $_POST['id'];
$cbvarizi = "@chaergakdf";// channel pay
//==============================================================
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.idpay.ir/v1.1/payment/verify');
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
  'id' => $id,
  'order_id' => '1',
)));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  'Content-Type: application/json',
  "X-API-KEY: $MerchantID",
));
$result = json_decode(curl_exec($ch));
curl_close($ch);
//==============================================================
# -- @DevAbolfazl -- @IRA_Team -- #
if($result->status == '100' and mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `pay` WHERE `id` = '{$result->track_id}' LIMIT 1")) != true){
$connect->query("INSERT INTO `pay` (`id`) VALUES ('{$result->track_id}')");
$userdata = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `user` WHERE id = '$user' LIMIT 1"));
$pluscoin = $userdata["coin"]  +  $amount;
bot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"✅ #پرداخت_موفق با تشکر از خرید شما
🗣 موجودی حساب شما با موفقیت افزایش  یافت , در صورت وجود هر گونه ایراد کافیست با پشتیبانی در تماس باشید .
	
🛍 مبلغ پرداخت شده : $amount تومان
💰 موجودی جدید شما : $pluscoin تومان
💳 موجودی قبلی : {$userdata["coin"]} تومان",
	'reply_markup'=>$home
            ]);
$connect->query("UPDATE user SET `coin` = '$pluscoin' WHERE id = '$user' LIMIT 1");
$user = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '$user' LIMIT 1"));	
bot('sendmessage',[
	'chat_id'=>$channelkharid,
	'text'=>"✅ #پرداخت موفق
	
💎 مبلغ خرید : $amount تومان
👤 کاربر : [$user](tg://user?id=$user)
📞 شماره فرد = {$user['phone']}",
'parse_mode'=>'Markdown',
            ]);
if($userdata['inviter'] != '0'){
$userinviter = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM user WHERE id = '{$userdata['inviter']}' LIMIT 1"));
$porsant = ($amount * 10) / 100 ;
$coinplusinviter = $userinviter["coin"] + $porsant;
bot('sendmessage',[
	'chat_id'=>$userdata['inviter'],
	'text'=>"✅ تبریک ! زیر مجموعه شما از ربات خرید کرد و 10 درصد از موجودی خریداری شده به عنوان هدیه به شما تعلق گرفت
🗣 موجودی حساب شما با موفقیت افزایش  یافت , در صورت وجود هر گونه ایراد کافیست با پشتیبانی در تماس باشید .
	
🛍 موجودی خریداری شده : $amount تومان
💰 موجودی جدید شما : $coinplusinviter تومان
❄️ موجودی قبلی : {$userinviter["coin"]} تومان
🎁 مقدار هدیه : $porsant تومان
👤 خرید توسط : [$user](tg://user?id=$user)",
'parse_mode'=>'Markdown',
            ]);
$connect->query("UPDATE user SET `coin` = '$coinplusinviter' WHERE id = '{$userdata['inviter']}' LIMIT 1");
}
# -- @DevAbolfazl -- @IRA_Team -- #
?>
<html>
	<head>
		<title>ربات پاندا سین</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="description" content="ربات پاندا سین | صفحه افزایش موجودی ربات پاندا سین">
        <meta name="keywords" content="ربات پاندا سین">
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/rtl.css" />
		<link rel="icon" type="image/png" href="images/fav.png">
	</head>
	<body>
		<!-- Wrapper -->
			<div id="wrapper">
				<!-- Header -->
					<header id="header" class="alt">
						<h1>ربات پاندا سین</h1>
						<p>صفحه افزایش موجودیِ حساب</p>
					</header>
				<!-- Main -->
					<div id="main">
					<!-- First Section -->
										<section id="intro" class="main">
								<div class="spotlight">
									<div class="content">
										<header class="major">
											<h2>پرداخت شما با موفقیت انجام شد و موجودی حساب شما با موفقیت افزایش یافت</h2>
										</header>
										<ul class="actions">
											<li><a href="<?php echo "https://t.me/$usernamebot";?>" class="button">برگشت به ربات</a></li>
										</ul>
									</div>
								</div>
							</section>
					</div>		
			</div>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	</body>
</html>
<?php 
} else {
	bot('sendmessage',[
	'chat_id'=>$user,
	'text'=>"❌ پرداخت شما با موفقیت انجام نشد ! 
🔘 به منوی اصلی بازگشتید , میتوانید مجدد نسبت به افزایش موجودی حساب خود اقدام کنید .",
	'reply_markup'=>$home
            ]);
?>
<html>
	<head>
		<title>ربات پاندا سین</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="description" content="ربات پاندا سین | صفحه افزایش موجودی ربات پاندا سین">
        <meta name="keywords" content="ربات پاندا سین">
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/rtl.css" />
		<link rel="icon" type="image/png" href="images/fav.png">
	</head>
	<body>
		<!-- Wrapper -->
			<div id="wrapper">
				<!-- Header -->
					<header id="header" class="alt">
						<h1>ربات پاندا سین</h1>
						<p>صفحه افزایش موجودیِ حساب</p>
					</header>
				<!-- Main -->
					<div id="main">
					<!-- First Section -->
										<section id="intro" class="main">
								<div class="spotlight">
									<div class="content">
										<header class="major">
											<h2>پرداخت شما با موفقیت انجام نشد ! به ربات برگشته و مجدد اقدام به خرید کنید</h2>
										</header>
										<ul class="actions">
											<li><a href="<?php echo "https://t.me/$usernamebot";?>" class="button">برگشت به ربات</a></li>
										</ul>
									</div>
								</div>
							</section>
					</div>		
			</div>
		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
	</body>
</html>
<?php 
}

?>