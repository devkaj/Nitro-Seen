<?php

@$Token = 'asfdasfaf'; // توکن ربات
// اطلاعات دیتابیس ربات
@$db_name       = "asfsafas";
@$db_username   = "asfasf";
@$db_password   = "asfasfasf";
//-------------------------//
$merid = "asdasfad"; //apikey کد نکست پی
$cbvarizi = "@asfsafsaf";// channel pay
//----------------------------------------------------------------------------
define('API_KEY', $Token);
function bot($method, $datas = []){
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    if (curl_error($ch)) {
        var_dump(curl_error($ch));
    } else {
        return json_decode($res);
    }
}
//---------------------------------//
function sendMessage($chat_id, $text, $key = null){
    bot('sendMessage', [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'Html',
        'disable_web_page_preview' => true,
        'reply_markup' => $key
    ]);
}
$con = mysqli_connect("localhost",$db_username,$db_password,$db_name);
mysqli_query($con, "SET NAMES 'utf8mb4'");
if(mysqli_query($con, "SELECT * FROM `setting`") == false){
}
@$botext = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `text` WHERE `id` = '1' LIMIT 1"));
@$off = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `off` WHERE `id` = '1' LIMIT 1"));
@$setting = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `setting` WHERE `id` = '1' LIMIT 1"));
@$channels = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `channel` WHERE `id` = '1' LIMIT 1"));
@$admin = mysqli_num_rows(mysqli_query($con, "SELECT `id` FROM `works` WHERE `id`='$fid' LIMIT 1"));
//---------------دکمه ها------------------//