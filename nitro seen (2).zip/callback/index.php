<?php
include 'config.php';

error_reporting(0);
date_default_timezone_set('Asia/Tehran');
$time = date('H:i:s');
$date = date('Y/m/d');
$amount = $_GET["amount"];
$trans_id = $_GET["trans_id"];
$order_id =  $_GET["order_id"];
$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://nextpay.org/nx/gateway/verify',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => "api_key=$merid&amount=$amount&trans_id=$trans_id",
));

$response = curl_exec($curl);

curl_close($curl);
$dashp = file_get_contents("data.txt");
$_array = json_decode($response , true);
$code = $_array['code'];
$amount = $_array['amount'];
$order_id = $_array['order_id'];
$Shaparak_Ref_Id = $_array['Shaparak_Ref_Id'];
$custom = $_array['custom'];
$cusn = json_decode($custom , true);
$userid = $cusn['userid'];
if($code == 0){
if(strpos($dashp, $Shaparak_Ref_Id) == false){
$user = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM `user` WHERE `id` = '$userid' LIMIT 1"));
$coin = $user['coin'];
$amu = $coin + $amount;
mysqli_query($con,"UPDATE `user` SET `step`='none',`coin`='$amu' WHERE `id`='$userid' LIMIT 1");
$con->query("INSERT INTO `buy` (`id` , `amount` , `time`) VALUES ('$userid' , '$amount' , '$date $time')");
$text = "✅ تراکنش شما با موفقیت انجام شد و موجودی حساب شما افزایش یافت.

💰 مقدار $amount تومان به حساب شما افزوده شد.
✅ شماره پیگیری : $Shaparak_Ref_Id

🙏🏻 باتشکر از خرید شما.";
bot('sendmessage',[
'chat_id'=>$userid,
'text'=>"$text",
'parse_mode'=>'Markdown',
]);
$coin = $user['coin'];
$amu = $coin + $amount;
bot('sendmessage',[
'chat_id'=>$cbvarizi,
'text'=>"✅ یک پرداخت با مشخصات زیر هم اکنون صورت گرفت.

☑️ مبلغ پرداخت شده : $amount تومان
💰 موجودی جدید کاربر : $amu سکه
⏱ زمان پرداخت : $time
📆 تاریخ : $date
👤 [جهت مشاهده کاربر کلیک نمایید.](tg://user?id=$userid)
",
'parse_mode'=>'Markdown',
]);
}
echo "<B>✅پرداخت موفق بود.</B>";
if(strpos($dashp, $Shaparak_Ref_Id) == false){
if(!in_array($dashp, $Shaparak_Ref_Id)){
  $add_user = file_get_contents('data.txt');
  $add_user .= $Shaparak_Ref_Id . "\n";
  file_put_contents('data.txt', $add_user);
  }
  
}}
elseif($code !== 0){
    $text = "❌پرداخت ناموفق بود.

✅کاربر گرامی درصورتی از حساب شما پول کسر شده است تا 72 ساعت آینده صبر کنید تا برگشت شود به حسابتان.

⏰ساعت : $time
📅تاریخ : $tada";
bot('sendmessage',[
'chat_id'=>$userid,
'text'=>"$text",
'parse_mode'=>'Markdown',
]);
echo "<B>❌پرداخت ناموفق بود.</B>";
}
?>