<?php
/*
@ImDevAbolfazl
*/
include '../botedmatike3iotfaka.php';
include '../config.php';
error_reporting(0);

//======================// Order Seen //=======================
$orderseen = mysqli_query($connect,"SELECT * FROM `orderseen` WHERE `stats` = '0'");
while($row = mysqli_fetch_assoc($orderseen)) {
$result = curl("$webapi/?apikey=$apikey&type=status-v&id={$row['key']}");


if($result->stats=='1'){
echo "ok \n";
$exlink = explode('/', $row['link']);
 $channelorder = $exlink[count($exlink) - 2];
 $id = end($exlink);
 bot('sendmessage',[
'chat_id'=>$row['id'],
 'text'=>"✅ سفارش بازدید با شماره پیگیری {$row['key']} با موفقیت #تکمیل شد .

⚡️ سرعت تکمیل : {$row['speed']}
⏱ زمان : {$row['time']}
💰 هزینه سفارش : {$row['amount']} تومان
👁‍🗨 تعداد بازدید درخواستی : {$row['view']}
",]);

 $connect->query("UPDATE `orderseen` SET `stats` = '1' WHERE `key` = '{$row['key']}' LIMIT 1");
}

if($result->stats=='2'){
echo "ok \n";
$exlink = explode('/', $row['link']);
 $channelorder = $exlink[count($exlink) - 2];
 $id = end($exlink);
 bot('sendmessage',[
'chat_id'=>$row['id'],
 'text'=>"❌ سفارش بازدید با شماره پیگیری {$row['key']} #لغو شد .
",]);

 $connect->query("UPDATE `orderseen` SET `stats` = '2' WHERE `key` = '{$row['key']}' LIMIT 1");
}
}

//======================// Order Like //=======================

$orderlike = mysqli_query($connect,"SELECT * FROM `orderlike` WHERE `stats` = '0'");
while($row = mysqli_fetch_assoc($orderlike)) {
$result = curl("$webapi/?apikey=$apikey&type=status-l&id={$row['key']}");


if($result->stats=='1'){
echo "ok \n";
$exlink = explode('/', $row['link']);
 $channelorder = $exlink[count($exlink) - 2];
 $id = end($exlink);
 bot('sendmessage',[
'chat_id'=>$row['id'],
 'text'=>"✅ سفارش لایک با شماره پیگیری {$row['key']} با موفقیت #تکمیل شد .

⚡️ سرعت تکمیل : {$row['speed']}
⏱ زمان : {$row['time']}
💰 هزینه سفارش : {$row['amount']} تومان
♥️ تعداد لایک درخواستی : {$row['like']}
",]);

 $connect->query("UPDATE `orderlike` SET `stats` = '1' WHERE `key` = '{$row['key']}' LIMIT 1");
}

if($result->stats=='2'){
echo "ok \n";
$exlink = explode('/', $row['link']);
 $channelorder = $exlink[count($exlink) - 2];
 $id = end($exlink);
 bot('sendmessage',[
'chat_id'=>$row['id'],
 'text'=>"❌ سفارش لایک با شماره پیگیری {$row['key']} #لغو شد .
",]);

 $connect->query("UPDATE `orderlike` SET `stats` = '2' WHERE `key` = '{$row['key']}' LIMIT 1");
}
}

//======================// Order Reaction //=======================

$orderreaction = mysqli_query($connect,"SELECT * FROM `orderreaction` WHERE `stats` = '0'");
while($row = mysqli_fetch_assoc($orderreaction)) {
$result = curl("$solowebapi/?user=$adminapi&key=$apisolo&action=order-v2&order={$row['key']}");

if($result->Status=='Done'){
echo "ok \n";
$exlink = explode('/', $row['link']);
 $channelorder = $exlink[count($exlink) - 2];
 $id = end($exlink);
 bot('sendmessage',[
'chat_id'=>$row['id'],
 'text'=>"✅ سفارش ری اکشن با شماره پیگیری {$row['key']} با موفقیت #تکمیل شد .

⚡️ سرعت تکمیل : حداکثر سرعت
⏱ زمان : حداکثر
💰 هزینه سفارش : {$row['amount']} تومان
",]);

 $connect->query("UPDATE `orderreaction` SET `stats` = '1' WHERE `key` = '{$row['key']}' LIMIT 1");
}

if($result->Status=='Canceled'){
echo "ok \n";
$exlink = explode('/', $row['link']);
 $channelorder = $exlink[count($exlink) - 2];
 $id = end($exlink);
 bot('sendmessage',[
'chat_id'=>$row['id'],
 'text'=>"❌ سفارش ری اکشن با شماره پیگیری {$row['key']} #لغو شد .
",]);

 $connect->query("UPDATE `orderreaction` SET `stats` = '2' WHERE `key` = '{$row['key']}' LIMIT 1");
}
}